#!/usr/bin/env python3
import glob
import os

# ---------------------------
# Insert after imports (HISTORY_check.py)
# ---------------------------
import matplotlib as mpl
import matplotlib.pyplot as plt
import mesa_reader as mr
import numpy as np
from matplotlib.animation import FuncAnimation

# Import functions from static version for consistency
from plot_history import MesaView  # get_mesa_phase_info,
from plot_history import read_header_columns, setup_hr_diagram_params


NEWTON_ITER_PATHS = [
    "../SED/iteration_colors.data",
    "SED/iteration_colors.data",
    "iteration_colors.data",
]


def age_colormap_colors(ages, cmap_name="inferno", recent_fraction=0.25, stretch=5.0):
    """
    Map ages -> RGBA colors with these properties:
      - cmap_name: 'inferno'|'plasma'|'magma', etc.
      - recent_fraction: fraction (0..1) of the top of the age range that
                         receives most of the color variation (default 0.25).
      - stretch: non-linear exponent applied to normalized ages to compress older ages.
                 larger -> more compression of old ages (default 5.0).
    Behavior:
      - Colors update with the min/max of `ages` passed in each call.
      - We first normalize ages to [0,1] using current min/max.
      - Apply non-linear transform that compresses the lower (1-recent_fraction)
        and expands the top `recent_fraction` so the most recent quarter is "hot".
    """
    ages = np.asarray(ages, dtype=float)
    # handle degenerate case
    if ages.size == 0:
        return np.zeros((0, 4))

    amin, amax = ages.min(), ages.max()
    span = amax - amin if amax > amin else 1.0
    nrm = (ages - amin) / span
    # Nonlinear compressor that allocates most dynamic range to the top `recent_fraction`.
    # We'll compress lower portion via a power transform, then rescale piecewise.
    rf = float(np.clip(recent_fraction, 1e-6, 0.99))
    # first apply power-law compression to whole range (older ages -> smaller)
    nrm_pow = nrm**stretch

    # Now remap such that nrm_pow in [0, 1-rf] -> [0, 0.05] (very dark ramp),
    # and nrm_pow in [1-rf,1] -> [0.05,1.0] (main color variation).
    cutoff = 1.0 - rf
    below = nrm_pow <= cutoff
    above = ~below
    remapped = np.empty_like(nrm_pow)
    if cutoff <= 0:
        # degenerate: everything treated as recent
        remapped = nrm_pow
    else:
        # compress the big older chunk into a small lower band [0, low_band]
        low_band = 0.02  # almost-black band for the old bulk
        # linear rescale below cutoff into [0, low_band]
        if below.any():
            remapped[below] = (nrm_pow[below] / cutoff) * low_band
        # rescale above cutoff into [low_band, 1.0]
        if above.any():
            remapped[above] = low_band + (
                (nrm_pow[above] - cutoff) / (1.0 - cutoff)
            ) * (1.0 - low_band)

    # Ensure in [0,1]
    remapped = np.clip(remapped, 0.0, 1.0)

    cmap = mpl.cm.get_cmap(cmap_name)
    colors = cmap(remapped)  # RGBA Nx4
    return colors


def get_improved_mesa_phase_info(phase_code):
    """
    Map MESA's phase_of_evolution integer codes to phase names and more intuitive colors.
    Colors follow stellar evolution logic: blue (hot/young) -> red (cool/evolved) -> white (remnants)
    """
    # Improved phase colors that make physical sense
    phase_map = {
        -1: ("Relax", "#808080"),  # Gray - Relaxation phase
        1: ("Starting", "#E6E6FA"),  # Lavender - Starting phase
        2: ("Pre-MS", "#9370DB"),  # Medium purple - Pre-main sequence (young)
        3: ("ZAMS", "#4169E1"),  # Royal blue - Zero-age MS (hot, young MS)
        4: ("IAMS", "#00CED1"),  # Dark turquoise - Intermediate-age MS
        5: ("TAMS", "#FF6347"),  # Tomato - Terminal-age MS (cooler, evolved MS)
        6: ("He-Burn", "#FF4500"),  # Orange red - Helium burning (post-MS)
        7: ("ZACHeB", "#FF8C00"),  # Dark orange - Zero-age core helium burning
        8: ("TACHeB", "#FFA500"),  # Orange - Terminal-age core helium burning
        9: ("TP-AGB", "#DC143C"),  # Crimson - Thermally pulsing AGB (very evolved)
        10: ("C-Burn", "#B22222"),  # Fire brick - Carbon burning (massive stars)
        11: ("Ne-Burn", "#8B0000"),  # Dark red - Neon burning
        12: ("O-Burn", "#800000"),  # Maroon - Oxygen burning
        13: ("Si-Burn", "#654321"),  # Dark brown - Silicon burning (pre-collapse)
        14: ("WDCS", "#F5F5F5"),  # White smoke - White dwarf cooling sequence
    }

    return phase_map.get(phase_code, ("Unknown", "#696969"))  # Dim gray for unknown


def get_phase_info_from_mesa(md):
    """Get evolutionary phase information using MESA's phase_of_evolution if present.
    If missing, return None phase names and AGE-driven colors (inferno by default)."""
    # If present, use original behavior (map codes to names/colors)
    if hasattr(md, "phase_of_evolution"):
        phase_codes = md.phase_of_evolution
        phases = []
        phase_colors = []
        for code in phase_codes:
            phase_name, color = get_improved_mesa_phase_info(int(code))
            phases.append(phase_name)
            phase_colors.append(color)
        return phases, phase_colors

    # fallback: color by age using inferno colormap, updated every call
    # Warning message kept (but only once)
    print("Warning: phase_of_evolution not found in history file.")
    print("Make sure to add 'phase_of_evolution' to your history_columns.list")
    ages = getattr(md, "star_age", None)
    if ages is None:
        # nothing to color
        return [], []

    # choose params: recent_fraction=0.25 compress older ages heavily (stretch=5)
    colors = age_colormap_colors(
        ages, cmap_name="jet", recent_fraction=0.25, stretch=5.0
    )
    # produce placeholder phase names (None or empty is fine)
    phases = [None] * len(colors)
    phase_colors = list(colors)
    return phases, phase_colors


def get_filter_colors(filter_names):
    """Generate distinct colors for different filters."""
    # Use a colormap that provides good contrast
    cmap = plt.cm.Set1  # Good for distinct colors
    colors = []
    for i, filt in enumerate(filter_names):
        color = cmap(i / max(len(filter_names), 1))
        colors.append(color)
    return colors


class HistoryChecker:
    def __init__(self, history_file="../LOGS/history.data", refresh_interval=0.01):
        """
        Initialize the History checker with auto-refresh capability and MESA phase color coding.

        Args:
            history_file: Path to the MESA history.data file
            refresh_interval: Time in seconds between refresh attempts
        """
        self.history_file = history_file
        self.refresh_interval = refresh_interval
        self.last_modified = None

        # Create the figure and axes
        self.fig, self.axes = plt.subplots(
            2, 2, figsize=(18, 16), gridspec_kw={"hspace": 0.01, "wspace": 0.01}
        )

        self.update_flag = 0
        self._iter_warn_issued = False
        # Initial setup
        self.filter_columns = []
        self.iter_col_names = None
        self.iter_data = None
        self.phases = []
        self.phase_colors = []
        self.filter_colors = []
        self.update_data()
        self.setup_plot()

    def setup_plot(self):
        """Set up the plot with formatting and labels (titles removed, labels enlarged, top x-axis added)."""
        # Top-left plot: HR Diagram (Color vs. Magnitude)
        self.axes[0, 0].set_xlabel(self.hr_xlabel, fontsize=16)
        self.axes[0, 0].set_ylabel(self.hr_ylabel, fontsize=16)
        self.axes[0, 0].invert_yaxis()
        self.axes[0, 0].xaxis.set_ticks_position("top")
        self.axes[0, 0].xaxis.set_label_position("top")
        self.axes[0, 0].grid(True, alpha=0.3)

        # Top-right plot: Teff vs. Log_L
        self.axes[0, 1].set_xlabel("Teff (K)", fontsize=16)
        self.axes[0, 1].set_ylabel("Log L/L☉", fontsize=16)
        self.axes[0, 1].invert_xaxis()
        self.axes[0, 1].yaxis.set_label_position("right")
        self.axes[0, 1].yaxis.tick_right()
        self.axes[0, 1].xaxis.set_ticks_position("top")
        self.axes[0, 1].xaxis.set_label_position("top")
        self.axes[0, 1].grid(True, alpha=0.3)

        # Bottom-left plot: Age vs. Color Index
        self.axes[1, 0].set_xlabel("Age (years)", fontsize=16)
        self.axes[1, 0].set_ylabel(f"Color ({self.hr_xlabel})", fontsize=16)
        self.axes[1, 0].grid(True, alpha=0.3)

        # Bottom-right plot: Age vs. All Filter Magnitudes
        self.axes[1, 1].set_xlabel("Age (years)", fontsize=16)
        self.axes[1, 1].set_ylabel("Magnitude", fontsize=16)
        self.axes[1, 1].invert_yaxis()
        self.axes[1, 1].yaxis.set_label_position("right")
        self.axes[1, 1].yaxis.tick_right()
        self.axes[1, 1].grid(True, alpha=0.3)

        plt.tight_layout()
        plt.subplots_adjust(top=0.92)  # Adjust if needed for legend spacing

    def check_for_changes(self):
        """Check if history file has been modified since last check."""
        if not os.path.exists(self.history_file):
            print(f"Warning: History file {self.history_file} not found")
            return False

        current_mtime = os.path.getmtime(self.history_file)

        if self.last_modified is None or current_mtime > self.last_modified:
            self.last_modified = current_mtime
            return True

        return False

    def update_data(self):
        """Read data from history file and extract relevant columns."""
        if not os.path.exists(self.history_file):
            print(f"Warning: History file {self.history_file} not found")
            return

        try:
            # Read the MESA data
            self.md = mr.MesaData(self.history_file)
            self.md = MesaView(self.md, 5)
            # after: self.phases, self.phase_colors = get_phase_info_from_mesa(self.md)
            self.has_phase = (
                hasattr(self.md, "phase_of_evolution")
                and np.unique(self.md.phase_of_evolution).size > 1
            )

            # Basic stellar parameters
            self.Teff = self.md.Teff
            self.Log_L = self.md.log_L
            self.Log_g = self.md.log_g
            self.Log_R = self.md.log_R
            self.Star_Age = self.md.star_age
            self.Mag_bol = self.md.Mag_bol
            self.Flux_bol = np.log10(self.md.Flux_bol)

            # Read header columns using imported function
            self.all_cols, self.filter_columns = read_header_columns(self.history_file)

            # Set up HR diagram parameters using imported function
            (
                self.hr_color,
                self.hr_mag,
                self.hr_xlabel,
                self.hr_ylabel,
                self.color_index,
            ) = setup_hr_diagram_params(self.md, self.filter_columns)

            # Get evolutionary phase information using MESA's built-in phases with improved colors
            self.phases, self.phase_colors = get_phase_info_from_mesa(self.md)

            # Get filter colors for the magnitude plot
            self.filter_colors = get_filter_colors(self.filter_columns)

        except Exception as e:
            print(f"Error reading history data: {e}")

        self.load_newton_iter_data()

    def load_newton_iter_data(self):
        """Try to load Newton iteration data from the Colors SED output.
        Sets self.iter_col_names / self.iter_data, or None if unavailable.
        Warns once to terminal if the file cannot be found."""
        for path in NEWTON_ITER_PATHS:
            if os.path.exists(path):
                try:
                    with open(path, "r") as f:
                        header = f.readline().strip()
                    if header.startswith("#"):
                        header = header[1:].strip()
                    col_names = header.split()
                    data = np.loadtxt(path, comments="#")
                    if data.ndim == 1:
                        data = data.reshape(1, -1)
                    self.iter_col_names = col_names
                    self.iter_data = data
                    return
                except Exception as e:
                    if not self._iter_warn_issued:
                        print(
                            f"Warning: found {path} but failed to load Newton iteration data: {e}"
                        )
                        self._iter_warn_issued = True
                    self.iter_col_names = None
                    self.iter_data = None
                    return
        if not self._iter_warn_issued:
            print(
                "Warning: Newton iteration data not found "
                "(searched SED/iteration_colors.data). Skipping overlay."
            )
            self._iter_warn_issued = True
        self.iter_col_names = None
        self.iter_data = None

    def get_iter_col(self, name):
        """Return a column array from the iteration data by column name, or None."""
        if self.iter_col_names is None or self.iter_data is None:
            return None
        try:
            idx = self.iter_col_names.index(name)
            return self.iter_data[:, idx]
        except (ValueError, IndexError):
            return None

    def overlay_newton_iters(self, ax, x_data, y_data, label="Newton iter"):
        """Overlay Newton iteration points on an axis if both arrays are non-None."""
        if x_data is None or y_data is None:
            return
        x = np.asarray(x_data, dtype=float)
        y = np.asarray(y_data, dtype=float)
        mask = np.isfinite(x) & np.isfinite(y)
        if not np.any(mask):
            return
        ax.scatter(
            x[mask],
            y[mask],
            marker="x",
            s=40,
            linewidths=1.5,
            color="orange",
            alpha=0.85,
            label=label,
            zorder=5,
        )

    def resolve_iter_color_index(self):
        """Attempt to compute the same color index used for hr_color from iteration data.
        Parses hr_xlabel (e.g. 'B-V') into two filter column names and subtracts them."""
        xlabel = getattr(self, "hr_xlabel", "")
        # Strip surrounding parens if present
        xlabel = xlabel.strip("()")
        if "-" not in xlabel:
            return None
        parts = xlabel.split("-", 1)
        col_a = self.get_iter_col(parts[0].strip())
        col_b = self.get_iter_col(parts[1].strip())
        if col_a is None or col_b is None:
            return None
        return col_a - col_b

    def resolve_iter_hr_mag(self):
        """Attempt to get the hr magnitude column from iteration data using hr_ylabel."""
        ylabel = getattr(self, "hr_ylabel", "")
        # ylabel might be e.g. "V" or "Mv" — try direct lookup
        col = self.get_iter_col(ylabel.strip())
        if col is not None:
            return col
        # Also strip common magnitude prefixes
        for prefix in ("M_", "Mv", "m_"):
            stripped = ylabel.replace(prefix, "").strip()
            col = self.get_iter_col(stripped)
            if col is not None:
                return col
        return None

    def create_phase_legend(self):
        unique_phases, unique_colors = [], []
        for phase, color in zip(self.phases, self.phase_colors):
            if phase is None:  # ignore fallback age-color entries
                continue
            if phase not in unique_phases:
                unique_phases.append(phase)
                unique_colors.append(color)
        return [
            plt.Line2D(
                [0],
                [0],
                marker="o",
                color="w",
                markerfacecolor=color,
                markersize=8,
                label=phase,
                markeredgecolor="none",
            )
            for phase, color in zip(unique_phases, unique_colors)
        ]

    def update_plot(self, frame):
        """Update the plot with new data if the file has changed."""
        if not self.check_for_changes():
            return

        if self.update_flag < 5:
            print(f"Detected changes in {self.history_file}, updating plot...")
            self.update_flag = self.update_flag + 1
        elif self.update_flag == 5:
            print(
                f"... MESA is clearly running so no more updates about: {self.history_file}"
            )
            self.update_flag = self.update_flag + 1

        # Update data
        self.update_data()

        # Clear all axes
        for ax in self.axes.flatten():
            ax.clear()

        # Reset plot formatting
        self.setup_plot()

        # Top-left plot: HR Diagram with phase colors
        if len(self.phases) > 0:
            self.axes[0, 0].plot(
                self.hr_color,
                self.hr_mag,
                marker=",",
                linestyle="-",
                color="k",
                alpha=0.2,
            )

            self.axes[0, 0].scatter(
                self.hr_color,
                self.hr_mag,
                c=self.phase_colors,
                s=15,
                alpha=0.9,
                linestyle="-",
                edgecolors="none",
            )
        else:
            self.axes[0, 0].plot(self.hr_color, self.hr_mag, "go")

        # Overlay Newton iteration data on HR diagram
        self.overlay_newton_iters(
            self.axes[0, 0],
            self.resolve_iter_color_index(),
            self.resolve_iter_hr_mag(),
        )

        # Top-right plot: Teff vs. Log_L with phase colors
        if len(self.phases) > 0:
            self.axes[0, 1].plot(
                self.Teff,
                self.Log_L,
                marker=",",
                linestyle="-",
                color="k",
                alpha=0.2,
            )

            self.axes[0, 1].scatter(
                self.Teff,
                self.Log_L,
                c=self.phase_colors,
                s=15,
                alpha=0.9,
                linestyle="-",
                edgecolors="none",
            )
        else:
            self.axes[0, 1].plot(self.Teff, self.Log_L, "go")

        # Overlay Newton iteration data on Teff vs log_L
        self.overlay_newton_iters(
            self.axes[0, 1],
            self.get_iter_col("Teff"),
            self.get_iter_col("log_L"),
        )

        # Bottom-left plot: Age vs. Color Index with phase colors
        if len(self.phases) > 0:
            self.axes[1, 0].plot(
                self.Star_Age,
                self.color_index,
                marker=",",
                linestyle="-",
                color="k",
                alpha=0.2,
            )

            self.axes[1, 0].scatter(
                self.Star_Age,
                self.color_index,
                c=self.phase_colors,
                s=15,
                alpha=1,
                linestyle="-",
                edgecolors="none",
            )

        else:
            self.axes[1, 0].plot(self.Star_Age, self.color_index, "kx")

        for i, filt in enumerate(self.filter_columns):
            try:
                col_data = getattr(self.md, filt)
            except AttributeError:
                try:
                    col_data = self.md.data(filt)
                except Exception:
                    print(f"Warning: Could not retrieve data for filter {filt}")
                    continue

            col_data = np.asarray(col_data, dtype=float)
            age = np.asarray(self.Star_Age, dtype=float)

            # --- physical mask ---
            mask = (
                np.isfinite(col_data)
                & np.isfinite(age)
                & (col_data < 90.0)  # magnitude sanity bound
                & (col_data > -50.0)  # avoid garbage negatives
            )

            if not np.any(mask):
                # Entire column is non-physical → skip it
                continue

            color = self.filter_colors[i] if i < len(self.filter_colors) else "black"

            self.axes[1, 1].plot(
                age[mask],
                col_data[mask],
                marker="o",
                linestyle="-",
                label=filt,
                color=color,
                markersize=3,
                alpha=0.8,
            )

        # Add evolutionary phase legend at the top of the figure
        if len(self.phases) > 1:
            # Add legend to filter plot
            self.axes[1, 1].legend()

        # --- legend block ---
        if getattr(self, "has_phase", False):
            legend_elements = self.create_phase_legend()
            if len(legend_elements) > 0:
                # optional: also keep the filter legend on bottom-right axes
                self.axes[1, 1].legend()

                n_phases = len(legend_elements)
                ncol = max(1, (n_phases + 1) // 1)  # same as before; tweak if needed
                self.fig.legend(
                    handles=legend_elements,
                    loc="upper center",
                    bbox_to_anchor=(0.5, 0.53),
                    ncol=ncol,
                    title_fontsize=10,
                    fontsize=10,
                    frameon=True,
                    fancybox=True,
                    shadow=True,
                )

        # Adjust layout to make room for top legend
        plt.tight_layout()
        plt.subplots_adjust(top=0.92)

        # Update the figure
        self.fig.canvas.draw_idle()

    def run(self):
        """Start the auto-refreshing display."""
        print(f"Monitoring history file: {self.history_file}")
        print(f"Refresh interval: {self.refresh_interval} seconds")
        print("Using MESA's built-in phase_of_evolution for color coding")
        print("Make sure 'phase_of_evolution' is in your history_columns.list")
        print("\nMESA Phase Definitions:")
        print("  -1: Relax, 1: Starting, 2: Pre-MS, 3: ZAMS, 4: IAMS, 5: TAMS")
        print("  6: He-Burn, 7: ZACHeB, 8: TACHeB, 9: TP-AGB")
        print("  10: C-Burn, 11: Ne-Burn, 12: O-Burn, 13: Si-Burn, 14: WDCS")

        # Initial plot
        self.update_plot(0)

        # Set up animation
        self.animation = FuncAnimation(
            self.fig,
            self.update_plot,
            interval=self.refresh_interval * 1000,  # Convert to milliseconds
            cache_frame_data=False,
        )

        # Show the plot (this will block until window is closed)
        plt.show()


def main():
    # Locate the history.data file
    try:
        history_file = glob.glob("../LOGS/history.data")[0]
    except IndexError:
        history_file = "../LOGS/history.data"  # Default path if not found
        print(f"Warning: No history.data file found, will check for {history_file}")

    checker = HistoryChecker(history_file=history_file, refresh_interval=0.1)
    checker.run()


if __name__ == "__main__":
    main()
